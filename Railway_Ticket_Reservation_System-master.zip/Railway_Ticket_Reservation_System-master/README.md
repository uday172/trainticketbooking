# Railway_Ticket_Reservation_System
This is a code of railway ticket reservation system using HTML, CSS, and JavaScript. On this web page, there are 5 menus and so many sub-menus. From this page, you can book train tickets, Book your meal, Find holiday packages, Services which are available at the station and there is Contact Us Form.
This is just like irctc.co.in(Indian railway ticket booking website)
